
CREATE SEQUENCE id_objednavky_seq
  START WITH 1
  INCREMENT BY 1
  MINVALUE 1
  NO CYCLE;

-- Získanie novej hodnoty
SELECT NEXTVAL('id_objednavky_seq');  

-- Získanie poslednej hodnoty
SELECT CURRVAL('id_objednavky_seq');  

-- Použitie v INSERT príkaze
INSERT INTO objednavky (id, produkt_id)
VALUES (NEXTVAL('id_objednavky_seq'), 123);  

-- 📦 2. Tabuľka produkty
CREATE TABLE produkty_elektro (
    id SERIAL PRIMARY KEY,
    nazov VARCHAR(100),
    cena NUMERIC(10, 2)
);

-- 📥 3. Tabuľka objednavky
CREATE TABLE objednavky_elektro (
    id INT PRIMARY KEY DEFAULT NEXTVAL('id_objednavky_seq'),
    produkt_id INT REFERENCES produkty_elektro(id),
    datum TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 🔄 4. Vloženie 20 produktov
INSERT INTO produkty_elektro (nazov, cena) VALUES
('Bezdrôtová myš Logitech M185', 15.90),
('Mechanická klávesnica Redragon K552', 49.99),
('Monitor Dell 24" Full HD', 129.00),
('Externý disk WD Elements 1TB', 55.50),
('USB kľúč Kingston 64GB', 9.99),
('Notebook Lenovo IdeaPad 3', 499.00),
('Slúchadlá JBL Tune 500', 25.90),
('Webkamera Logitech C920', 89.99),
('Powerbanka Xiaomi 10000mAh', 18.75),
('Bluetooth reproduktor Sony SRS-XB13', 39.90),
('Smartfón Samsung Galaxy A13', 179.00),
('Chladiaca podložka pre notebooky', 14.50),
('Router TP-Link Archer C6', 34.90),
('Herná myš Razer DeathAdder', 59.00),
('Mikrofón Trust GXT 232', 28.70),
('Držiak na monitor', 21.60),
('Adaptér USB-C na HDMI', 12.40),
('SSD Kingston 500GB', 59.90),
('Podložka pod myš XXL', 7.99),
('Čistiaca sada na notebook', 4.99);

-- 📦 5. Vygenerovanie 100 objednávok náhodne
-- Použiteľný skript pre PostgreSQL pomocou generate_series:
INSERT INTO objednavky_elektro (produkt_id)
SELECT (RANDOM() * 19 + 1)::INT
FROM generate_series(1, 100);


-- ✅ Overenie počtu riadkov
SELECT COUNT(*) FROM objednavky_elektro;

-----------------------------------------------------------------

-- 🆕 Skript s náhodným dátumom posledných 30 dní
INSERT INTO objednavky_elektro (produkt_id, datum)
SELECT 
  (RANDOM() * 19 + 1)::INT AS produkt_id,
  NOW() - (INTERVAL '1 day' * (RANDOM() * 30)) AS datum
FROM generate_series(1, 100);

---------------------------------------------------------------------

-- Príklad vlastnej sekvencie
CREATE SEQUENCE cislo_faktury_seq START 1000;

SELECT NEXTVAL('cislo_faktury_seq');  -- 1000
SELECT NEXTVAL('cislo_faktury_seq');  -- 1001


-- Alternatíva k manuálnym sekvenciám
CREATE TABLE zakaznici2 (
  id SERIAL PRIMARY KEY,
  meno TEXT
);

-- Ekvivalent k:
CREATE SEQUENCE zakaznici_id_seq;
CREATE TABLE zakaznici2 (
  id INTEGER PRIMARY KEY 
    DEFAULT NEXTVAL('zakaznici_id_seq'),
  meno TEXT
);
    

-- Použitie sekvencie v tabuľke cez DEFAULT
CREATE SEQUENCE cislo_faktury_seq START 1000;
-- Poznámka: Parametre ako INCREMENT, MINVALUE, MAXVALUE sú voliteľné

CREATE TABLE faktury (
  id INT DEFAULT NEXTVAL('cislo_faktury_seq'),
  suma NUMERIC
  -- Poznámka: Môžete pridať ďalšie stĺpce podľa potreby
);

-- Vloženie bez uvedenia ID
INSERT INTO faktury (suma) VALUES (99.99);
-- Poznámka: PostgreSQL automaticky zavolá NEXTVAL('cislo_faktury_seq')


-- Úprava existujúcej sekvencie
ALTER SEQUENCE id_objednavky_seq
  INCREMENT BY 5
  MINVALUE 100
  MAXVALUE 10000
  RESTART WITH 500;
  

-- ✅ Bezpečné riešenie v troch krokoch

🧩 1. Odstrániť DEFAULT hodnotu zo stĺpca id (dočasne)
ALTER TABLE objednavky_elektro ALTER COLUMN id DROP DEFAULT;

🧨 2. Zmazať a znovu vytvoriť sekvenciu
DROP SEQUENCE IF EXISTS id_objednavky_seq;

CREATE SEQUENCE id_objednavky_seq
  INCREMENT BY 5
  MINVALUE 100
  MAXVALUE 10000
  START WITH 500;
  
🔗 3. Opätovne priradiť sekvenciu ako DEFAULT pre id
ALTER TABLE objednavky_elektro 
ALTER COLUMN id SET DEFAULT NEXTVAL('id_objednavky_seq');


------------------------------------------------------------
    
-- Získanie informácií o sekvencii
SELECT * FROM 
  pg_sequences
WHERE 
  sequencename = 'id_objednavky_seq';
    
	
-- Ako vypisať vsetky sekvencie
-- 1. 📜  Pomocou čistého SQL dopytu
-- Tento dopyt vypíše všetky sekvencie v databáze (aj systémové, ak sú prístupné) spolu s menom schémy.

SELECT sequence_schema, sequence_name
FROM information_schema.sequences
ORDER BY sequence_schema, sequence_name;

-- ⚙️ 2. Pomocou metapríkazu (psql terminál)
\ds

-- alebo obmedzenejšie len na sekvencie:
\dsS+

– \ds = zobrazí všetky sekvencie a funkcie so symbolom S
– S+ = zobrazí aj ďalšie detaily (typ, vlastník, schéma)

-- 🔍 Voliteľne: filtrovať len vlastné sekvencie

SELECT sequence_name
FROM information_schema.sequences
WHERE sequence_schema NOT IN ('pg_catalog', 'information_schema');

------------------------------------------------------------

-- Zrušenie sekvencie
-- Základné zrušenie
DROP SEQUENCE id_objednavky_seq;

-- S kontrolou existencie
DROP SEQUENCE IF EXISTS id_objednavky_seq;

-- Pozor na závislosti
DROP SEQUENCE id_objednavky_seq CASCADE;


------------------------------------------------------------ 

-- Praktická úloha: Sekvencie
-- Úloha 5: Vytvoriť sekvenciu pre generovanie ID objednávok

CREATE SEQUENCE objednavka_seq
  START 5000
  INCREMENT 10;

------------------------------------------------------------


-- Pokročilé použitie sekvencií
-- Funkcia na generovanie ID
CREATE OR REPLACE FUNCTION 
  generuj_faktura_id()
RETURNS TEXT AS $$
DECLARE
  rok TEXT := to_char(CURRENT_DATE, 'YYYY');  -- Poznámka: Automaticky použije aktuálny rok
  cislo INT;
BEGIN
  SELECT NEXTVAL('faktura_seq') INTO cislo;  -- Poznámka: Získanie ďalšej hodnoty zo sekvencie
  RETURN 'FA-' || rok || '-' || 
         LPAD(cislo::TEXT, 5, '0');  -- Poznámka: Padding na 5 číslic
END;
$$ LANGUAGE plpgsql;


-- ✅ 1. Vytvorenie sekvencie pre faktúry (ak ešte neexistuje)
CREATE SEQUENCE IF NOT EXISTS faktura_seq START 1;


CREATE TABLE faktury_ostre (
  faktura_id TEXT PRIMARY KEY DEFAULT generuj_faktura_id(),  -- Automaticky generované ID
  zakaznik_id INT NOT NULL,  -- ID zákazníka
  suma NUMERIC(10, 2) NOT NULL  -- Suma faktúry v eurách
);

💡 Voliteľné použitie vo vkladaní:
INSERT INTO faktury_ostre (faktura_id, zakaznik_id, suma)
VALUES (generuj_faktura_id(), 42, 199.90);

------------------------------------------------------------
    
-- Zdieľanie sekvencií medzi tabuľkami
-- Vytvorenie sekvencie
CREATE SEQUENCE dokument_id_seq;

-- Použitie v prvej tabuľke
CREATE TABLE faktury_zalohove (
  id INT PRIMARY KEY DEFAULT NEXTVAL('dokument_id_seq'),
  cislo TEXT,
  suma NUMERIC
);

-- Použitie v druhej tabuľke
CREATE TABLE objednavky_testovacie (
  id INT PRIMARY KEY DEFAULT NEXTVAL('dokument_id_seq'),
  cislo TEXT,
  stav TEXT
);

-- 1. 🧪 Vkladať testovacie dáta
INSERT INTO faktury_zalohove (cislo, suma)
VALUES ('FZ-2025-001', 199.90);

INSERT INTO objednavky_testovacie (cislo, stav)
VALUES ('OBJ-2025-001', 'Vybavená');

-- 2. 🔍 Skontrolovať hodnoty zo sekvencie
SELECT currval('dokument_id_seq');  -- aktuálne použité číslo
SELECT nextval('dokument_id_seq');  -- ďalšie číslo (a zároveň posunie sekvenciu)
