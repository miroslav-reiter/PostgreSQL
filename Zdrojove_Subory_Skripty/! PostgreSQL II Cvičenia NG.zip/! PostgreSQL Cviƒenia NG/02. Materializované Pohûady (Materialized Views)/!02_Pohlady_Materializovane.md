
CREATE MATERIALIZED VIEW statistika_predaja AS
SELECT produkt_id, COUNT(*) AS pocet_predajov
FROM objednavky
GROUP BY produkt_id;


CREATE MATERIALIZED VIEW predaje_za_mesiac AS
SELECT produkt_id, SUM(cena) AS obrat
FROM predaje
WHERE datum >= date_trunc('month', CURRENT_DATE)
GROUP BY produkt_id;


REFRESH MATERIALIZED VIEW statistika_predaja;

-- Voliteľné parametre
REFRESH MATERIALIZED VIEW statistika_predaja WITH DATA;
REFRESH MATERIALIZED VIEW statistika_predaja WITH NO DATA;


-- Vytvorenie materializovaného pohľadu
CREATE MATERIALIZED VIEW statistika_produktov AS
SELECT kategoria_id, COUNT(*) AS pocet,
       AVG(cena) AS priemerna_cena
FROM produkty
GROUP BY kategoria_id;

-- Vytvorenie indexov
CREATE INDEX idx_stat_kategoria 
  ON statistika_produktov(kategoria_id);
CREATE INDEX idx_stat_pocet 
  ON statistika_produktov(pocet DESC);


-- Úloha 3: Vytvoriť materializovaný pohľad na predaje

CREATE MATERIALIZED VIEW predaje_mesacne AS
SELECT produkt_id, COUNT(*) AS pocet_predajov, 
       SUM(cena) AS trzba
FROM predaje
WHERE datum >= date_trunc('month', CURRENT_DATE)
GROUP BY produkt_id;

-- Úloha 4: Obnoviť materializovaný pohľad

REFRESH MATERIALIZED VIEW predaje_mesacne;


-- Príklad pg_cron (extension)
SELECT cron.schedule(
  'refresh_stats', -- názov úlohy
  '0 0 * * *',    -- každý deň o polnoci
  'REFRESH MATERIALIZED VIEW 
   statistika_predaja'
);
    


