
-- Pridávanie a aktivácia extensions
-- Kontrola dostupných extensions
SELECT * FROM pg_available_extensions;

------------------------------------------------------------------


-- Aktivácia extension
CREATE EXTENSION IF NOT EXISTS pg_stat_statements;

-- Kontrola nainštalovaných extensions
SELECT * FROM pg_extension;

pg_stat_statements Extension
-- Aktivácia v postgresql.conf:
-- shared_preload_libraries = 'pg_stat_statements'
-- Poznámka: Tento riadok musí byť pridaný pred spustením servera

-- Aktivácia v databáze
CREATE EXTENSION IF NOT EXISTS pg_stat_statements;
-- Poznámka: Vykonajte ako používateľ s admin právami

-- Overiť, či sa modul načítal správne
SHOW shared_preload_libraries;

------------------------------------------------------------------
cd C:\Program Files\PostgreSQL\17\bin

-- Spustite server v jednoúčelovom režime:
postgres --single -D "C:\Program Files\PostgreSQL\17\data" postgres


ALTER USER postgres WITH PASSWORD 'heslo-tajne';

Stlačte Ctrl + Z → Enter na ukončenie.
------------------------------------------------------------------
-- Príklad použitia
SELECT query, calls, total_exec_time
FROM pg_stat_statements
ORDER BY total_exec_time DESC;
-- Poznámka: Zobrazí dopyty zoradené podľa celkového času vykonávania

------------------------------------------------------------------

-- Príklad použitia pg_stat_statements
SELECT query, total_exec_time, calls, rows
FROM pg_stat_statements
ORDER BY total_exec_time DESC
LIMIT 5;


-- Príklad použitia pg_stat_statements
-- Najpomalšie dopyty

SELECT 
    substring(query, 1, 50) AS query_short,
    round(total_exec_time::numeric, 2) AS total_time,
    calls,
    round(mean_exec_time::numeric, 2) AS mean,
    round((100 * total_exec_time / 
          sum(total_exec_time) OVER ())::numeric, 2) AS percentage
FROM pg_stat_statements
ORDER BY total_exec_time DESC
LIMIT 5;

------------------------------------------------------------------

-- Príklad použitia tablefunc
-- Aktivácia extension
CREATE EXTENSION tablefunc;

CREATE EXTENSION IF NOT EXISTS tablefunc;


-- Použitie crosstab funkcie
SELECT * FROM crosstab(
  'SELECT oddelenie, rok, COUNT(*) 
   FROM zamestnanci 
   GROUP BY oddelenie, rok 
   ORDER BY 1,2',
  'SELECT DISTINCT rok FROM zamestnanci ORDER BY 1'
) AS ct (oddelenie TEXT, "2021" INT, "2022" INT, "2023" INT);


-- 🗄️ 1. Vytvorenie tabuľky zamestnanci
DROP TABLE IF EXISTS zamestnanci;

CREATE TABLE zamestnanci (
    id SERIAL PRIMARY KEY,
    meno TEXT,
    oddelenie TEXT,
    rok INT
);

-- 📥 2. Vloženie reálnych údajov (min. 50 riadkov)
INSERT INTO zamestnanci (meno, oddelenie, rok) VALUES
('Anna Kováčová', 'Marketing', 2021),
('Ján Novák', 'IT', 2021),
('Lucia Hrivnáková', 'HR', 2021),
('Marek Polák', 'IT', 2022),
('Petra Benová', 'Finance', 2022),
('Roman Švec', 'Marketing', 2022),
('Simona Krajčírová', 'HR', 2023),
('Igor Kubiš', 'Finance', 2023),
('Zuzana Bieliková', 'IT', 2023),
('Milan Brezina', 'Marketing', 2021),
('Karolína Dvorská', 'HR', 2022),
('Daniel Tóth', 'Finance', 2021),
('Barbora Krnáčová', 'IT', 2023),
('Jakub Horváth', 'Marketing', 2023),
('Vladimír Král', 'HR', 2021),
('Monika Cibuľová', 'Finance', 2022),
('Dávid Pavlík', 'IT', 2022),
('Emília Červeňáková', 'HR', 2023),
('Róbert Hruška', 'Marketing', 2022),
('Alena Suchá', 'Finance', 2023),
('Michal Černý', 'IT', 2021),
('Tatiana Kmeťová', 'Marketing', 2023),
('Adam Zeman', 'HR', 2022),
('Martina Uhríková', 'Finance', 2022),
('Erik Baláž', 'IT', 2021),
('Dominika Škultétyová', 'Marketing', 2022),
('Nina Gregorová', 'Finance', 2021),
('Radoslav Tomko', 'HR', 2023),
('Michaela Blašková', 'Finance', 2021),
('Ľuboš Vlček', 'IT', 2022),
('Renáta Gajdošová', 'Marketing', 2023),
('Peter Bača', 'HR', 2021),
('Lenka Kovárová', 'Finance', 2023),
('Ondrej Mišík', 'Marketing', 2021),
('Eva Maková', 'IT', 2023),
('Tomáš Jedinák', 'Finance', 2022),
('Veronika Melichová', 'HR', 2021),
('Richard Toma', 'IT', 2022),
('Sandra Pavlíková', 'Marketing', 2023),
('Katarína Juríčková', 'HR', 2023),
('Tibor Hlavatý', 'Finance', 2023),
('Edita Petrová', 'IT', 2021),
('Juraj Reiter', 'Marketing', 2022),
('Lucia Farkašová', 'HR', 2022),
('Branislav Duda', 'Finance', 2023),
('Kristína Letková', 'Marketing', 2021),
('Daniela Ondrejová', 'IT', 2023),
('Viliam Jano', 'Finance', 2021),
('Zdenka Tomášová', 'HR', 2023),
('Roman Mikuláš', 'IT', 2022),
('Tatiana Veselá', 'Marketing', 2022);


------------------------------------------------------------------

-- uuid-ossp Extension
-- Aktivácia extension
CREATE EXTENSION "uuid-ossp";
-- Poznámka: Vyžaduje adminské práva

-- Generovanie UUID
SELECT uuid_generate_v4();
-- Výsledok: 550e8400-e29b-41d4-a716-446655440000
-- Poznámka: Výsledok sa líši pri každom volaní

📚 Najčastejšie funkcie UUID
Funkcia	Popis
uuid_generate_v1()	UUID podľa času a MAC adresy
uuid_generate_v4()	Náhodne generovaný UUID (najčastejšie používaný)
uuid_generate_v5(namespace, name)	Na základe hashu (SHA-1)
gen_random_uuid()	Alternatíva z pgcrypto

-- Použitie v tabuľkách
CREATE TABLE dokumenty (
  id UUID PRIMARY KEY 
    DEFAULT uuid_generate_v4(),
  nazov TEXT,
  obsah TEXT
);
-- Poznámka: Zaberá 16 bajtov


-- Vloženie záznamu
INSERT INTO dokumenty (nazov, obsah) 
VALUES ('vyrocna sprava', 'toto je vyrocna sprava 2025...');

SELECT * FROM dokumenty 

------------------------------------------------------------------
-- Príklad použitia UUID

-- Vytvorenie tabuľky s UUID
CREATE TABLE users (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  username TEXT UNIQUE,
  email TEXT
);

-- Vloženie záznamu
INSERT INTO users (username, email) 
VALUES ('mreiter', 'mreiter@vita.sk');

-- Výber podľa UUID
SELECT * FROM users 
WHERE id = '550e8400-e29b-41d4-a716-446655440000';


------------------------------------------------------------------
-- Praktická úloha: Extensions
-- Úloha 7: Aktivovať a použiť rozšírenie uuid-ossp

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

SELECT uuid_generate_v4();  
-- napr. 550e8400-e29b-41d4-a716-446655440000

-- Poznámka: UUID poskytuje globálne unikátne identifikátory 
-- vhodné pre distribuované systémy a mikroslužby

-- Úloha 8: Získať najpomalší dopyt pomocou pg_stat_statements

CREATE EXTENSION IF NOT EXISTS pg_stat_statements;


SELECT query, total_exec_time
FROM pg_stat_statements
ORDER BY total_exec_time DESC
LIMIT 3;

-- Poznámka: pg_stat_statements sleduje štatistiky vykonávania 
-- SQL príkazov a pomáha identifikovať výkonnostné problémy

------------------------------------------------------------------

-- pgcrypto Extension
-- Aktivácia extension
CREATE EXTENSION pgcrypto;

-- Hashovanie hesla
SELECT crypt('moje_heslo', gen_salt('bf'));

-- Overenie hesla
SELECT (
  crypt('zadane_heslo', 
        'uložený_hash') = 'uložený_hash'
) AS heslo_je_spravne;


------------------------------------------------------------------

-- pg_trgm Extension
-- Aktivácia extension
CREATE EXTENSION pg_trgm;

-- Vytvorenie indexu pre fuzzy vyhľadávanie
CREATE INDEX idx_nazov_trgm ON produkty 
USING GIN (nazov gin_trgm_ops);

-- Vyhľadávanie podobných názvov
SELECT nazov, similarity(nazov, 'telefon')
FROM produkty
WHERE nazov % 'telefon'
ORDER BY similarity(nazov, 'telefon') DESC;


-- 🧱 1. Vytvorenie tabuľky produkty
DROP TABLE IF EXISTS produkty;

CREATE TABLE produkty (
    id SERIAL PRIMARY KEY,
    nazov TEXT NOT NULL
);

INSERT INTO produkty (nazov) VALUES
('mobilný telefón'),
('telefón s Androidom'),
('pevná linka'),
('smartfón'),
('bezdrôtový telefón'),
('inteligentný telefón'),
('iPhone 14'),
('Samsung Galaxy'),
('kancelársky telefón'),
('telefón na pevnú linku'),
('stolný telefón'),
('Bluetooth headset'),
('slúchadlá'),
('mobil'),
('notebook'),
('tablet'),
('myš'),
('klávesnica'),
('nabíjačka'),
('USB kábel'),
('smart hodinky'),
('monitor'),
('televízor'),
('reproduktor'),
('projektor'),
('webkamera'),
('dron'),
('herné konzoly'),
('Xbox Series X'),
('PlayStation 5'),
('mikrofón'),
('router'),
('modem'),
('adaptér'),
('externý disk'),
('SSD disk'),
('pevný disk'),
('pamäťová karta'),
('čistič obrazovky'),
('ochranné sklo'),
('kryt na telefón'),
('držiak na mobil'),
('selfie tyč'),
('ochrana displeja'),
('USB hub'),
('napájací kábel'),
('záložný zdroj'),
('grafická karta'),
('procesor'),
('základná doska'),
('RAM pamäť'),
('chladenie CPU');

-- 🔌 2. Aktivácia rozšírenia pg_trgm
CREATE EXTENSION IF NOT EXISTS pg_trgm;


-- ⚙️ 3. Vytvorenie GIN indexu pre fuzzy vyhľadávanie
CREATE INDEX idx_nazov_trgm 
ON produkty 
USING GIN (nazov gin_trgm_ops);

-- 🔍 4. Ukážka vyhľadávania podobných názvov
SELECT nazov, similarity(nazov, 'telefón') AS podobnost
FROM produkty
WHERE nazov % 'telefón'
ORDER BY podobnost DESC;


------------------------------------------------------------------
-- Príklad použitia hstore

-- Aktivácia extension
CREATE EXTENSION hstore;

-- Vytvorenie tabuľky s hstore stĺpcom
CREATE TABLE produkty (
  id SERIAL PRIMARY KEY,
  nazov TEXT,
  vlastnosti hstore
);

-- Vloženie dát
INSERT INTO produkty (nazov, vlastnosti)
VALUES ('Notebook', 
  'procesor=>i7, ram=>16GB, disk=>512GB');

-- Dopytovanie
SELECT nazov FROM produkty
WHERE vlastnosti -> 'ram' = '16GB';

------------------------------------------------------------------
-- Príklad použitia ltree

-- Aktivácia extension
CREATE EXTENSION ltree;

-- Vytvorenie tabuľky s hierarchiou
CREATE TABLE kategorie (
  id SERIAL PRIMARY KEY,
  nazov TEXT,
  cesta ltree
);

-- Vloženie dát
INSERT INTO kategorie (nazov, cesta) VALUES
  ('Elektronika', 'elektronika'),
  ('Počítače', 'elektronika.pocitace'),
  ('Notebooky', 'elektronika.pocitace.notebooky'),
  ('Herné', 'elektronika.pocitace.notebooky.herne');

-- Dopytovanie podstromu
SELECT nazov FROM kategorie
WHERE cesta <@ 'elektronika.pocitace';
